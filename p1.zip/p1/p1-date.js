/*

CIT 281 Project 1
Name: Drew Lesh

*/

const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
let indexOfDay = new Date().getDay();
console.log(days[indexOfDay]);